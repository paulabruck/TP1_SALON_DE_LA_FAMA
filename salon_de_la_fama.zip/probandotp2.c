#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>


int main(){
    //char vector_1[6];
    char* vector_2 = malloc(6);
    
    if(vector_2==NULL){
        return -1;
    }

    //vector_1[5]=1;
    vector_2[5]=1;
    //*(vector_2+5) =1;
    printf("%i\n",vector_2[5] );
    free(vector_2);

    return 0;

}
  
    /*
    if(str!=NULL){
        tamanio=strlen(str);
    }
    for(int i =0;i<tamanio;i++){
        vector=dividir_str(str,i,separador,vector);
        if(str[i]== separador){ 
            item=vector;
            if(item!=NULL){
                auxiliar1=vtradd(auxiliar1,item);  
                vector=NULL; 
            }
        }  
        auxiliar1=vtradd(auxiliar1,item);
    }*/






    
int largo_substring(const char* str , char separador){
    size_t largo_str=strlen(str);
    int contador=0;
     for(int i=0;i<largo_str ;i++){  
        if(str[i]!=separador){
            contador++;        
        }else if(str[i]== separador){
            return 0;
        }  
    }
    return contador;
}
char* dividir_str(const char* str , char separador, char* str_nuevo){
    int tamanio= largo_substring(str, separador);
    //str_nuevo=NULL;
    //void* auxiliar1=NULL;
    //char* item=NULL;
    //int i=0;
    //int j=0;
    char* auxiliar= realloc(str_nuevo, (sizeof tamanio+1));
        if(!auxiliar){
        free(auxiliar);
            return NULL;
        } 
        for(int i=0; i< tamanio; i++){
            for(int j=0; j<tamanio;j++){
                str_nuevo[j]=str[i];
            }
        }
        
        printf("%s",str_nuevo);
        str_nuevo =auxiliar;
        
        return str_nuevo;
   
    /*
    char* str_auxiliar=NULL;
    size_t j=0;
    if(str_nuevo!=NULL){
        j=strlen(str_nuevo);
    }
    if(str[i]!= separador){
        str_auxiliar= (char*)realloc(str_nuevo, (sizeof(char)*(j+2)));
        if(!str_auxiliar){
            free(str_auxiliar);
            return NULL;
        }
        str_nuevo= str_auxiliar;
        str_nuevo[j]= str[i];
        j++;
        str_nuevo[j]= BARRA_CERO;
    }
    return str_nuevo;
    */
   /*
}

char** split(const char* str, char separador){
    
    char* item=NULL;
    char* vector=NULL;
    void* auxiliar1=NULL;
    int i=0;
    if(str==NULL){
        return NULL;
    }
    if( strlen(str)<=0){
        return NULL;
    } 
    while(str[i]!= separador){ 
    vector=dividir_str(str,separador,vector);
    item=vector;
        printf("%s", item);
            if(item!=NULL){
                auxiliar1=vtradd(auxiliar1,item);  
                vector=NULL;   
            } 
            i++;
    }        
    return auxiliar1;        
    /*         
    while(str[i]!= separador){
        vector=dividir_str(str,i,separador,vector);
        item=vector;
        printf("%s", item);
            if(item!=NULL){
                auxiliar1=vtradd(auxiliar1,item);  
                vector=NULL;   
            }
    i++;
    }
    return auxiliar1;
    */
   /*
}
*/
fgets(str, 512, archivo)




char* dividir_str(const char* str , int i,char separador, char* str_nuevo){
  
    size_t j=0;    
    char* str_auxiliar=NULL;
   
    if(str_nuevo!=NULL){
        j=strlen(str_nuevo);
    }
    if(str[i]!= separador){
        str_auxiliar= (char*)realloc(str_nuevo, (sizeof(char)*(j+2)));
        if(!str_auxiliar){
            free(str_auxiliar);
            return NULL;
        }
        str_nuevo= str_auxiliar;
        str_nuevo[j]= str[i];
        j++;
        str_nuevo[j]= BARRA_CERO;
    }
    return str_nuevo;
    
}

char** split(const char* str, char separador){
    
    char* item=NULL;
    char* vector=NULL;
    void* auxiliar1=NULL;
    int i=0;
    if(str==NULL){
        return NULL;
    }
    if( strlen(str)<=0){
        return NULL;
    }       
           
    while(str[i]!= separador){
        vector=dividir_str(str,i,separador,vector);
        item=vector;
        printf("%s", item);
            if(item!=NULL){
                auxiliar1=vtradd(auxiliar1,item);  
                vector=NULL;   
            }
    i++;
    }
    return auxiliar1;
    
}




    
int largo_substring(const char* str , char separador){
    size_t largo_str=strlen(str);
    int contador=0;
     for(int i=0;i<largo_str ;i++){  
        if(str[i]!=separador){
            contador++;        
        }else if(str[i]== separador){
            return 0;
        }  
    }
    return contador;
}
char* dividir_str(const char* str , char separador, char* str_nuevo){
    int tamanio= largo_substring(str, separador);
    //str_nuevo=NULL;
    //void* auxiliar1=NULL;
    //char* item=NULL;
    //int i=0;
    //int j=0;
    char* auxiliar= realloc(str_nuevo, sizeof(tamanio+2));
        if(!auxiliar){
        free(auxiliar);
            return NULL;
        } 
        for(int i=0; i< tamanio; i++){
            for(int j=0; j<tamanio;j++){
                str_nuevo[j]=str[i];
            }
        }
        
        printf("%s",str_nuevo);
        str_nuevo =auxiliar;
        
        return str_nuevo;

}

char** split(const char* str, char separador){
    
    char* item=NULL;
    char* vector=NULL;
    char** auxiliar1=NULL;
    int i=0;
    if(str==NULL){
        return NULL;
    }
    if( strlen(str)<=0){
        return NULL;
    } 
    while(str[i]!= separador){ 
    vector=dividir_str(str,separador,vector);
    item=vector;
        printf("%s", item);
            if(item!=NULL){
                auxiliar1=vtradd((void*)auxiliar1,(void*)item);  
                vector=NULL;   
            } 
            i++;
    }        
    return auxiliar1;        
    
}





































#include "util.h"
#include <string.h>
const char BARRA_CERO= '\0';

size_t vtrlen(void* ptr){
    
    void** auxiliar= ptr;
    size_t contador=0;    
    if(auxiliar==NULL){
         return 0;
    }
    while(auxiliar[contador]!=NULL){
        contador++;   
    }
    return contador;  
     
}
void* vtradd(void* ptr, void* item){
    
    size_t tamanio= vtrlen(ptr);
    void** auxiliar = realloc(ptr, sizeof(item)*(tamanio+2));
    if(auxiliar==NULL){
        return NULL;
    }
    auxiliar[tamanio]=item;
    tamanio++;
    auxiliar[tamanio]=NULL;
    return auxiliar;
    
}
void vtrfree(void* ptr){
   size_t tamanio= vtrlen(ptr);
   void** auxiliar=ptr;
    if(ptr==NULL){
        return ;
    }
   for(int i=0; i<tamanio;i++){
       if(auxiliar[i]!=NULL){
           free(auxiliar[i]);
       }  
   }
   free(auxiliar);
}


char* dividir_str(const char* str , int i,char separador, char* str_nuevo){
  
    size_t j=0;    
    char* str_auxiliar=NULL;
   
    if(str_nuevo!=NULL){
        j=strlen(str_nuevo);
    }
    if(str[i]!= separador){
        str_auxiliar= (char*)realloc(str_nuevo, (sizeof(char)*(j+2)));
        if(!str_auxiliar){
            free(str_auxiliar);
            return NULL;
        }
        str_nuevo= str_auxiliar;
        str_nuevo[j]= str[i];
        j++;
        str_nuevo[j]= BARRA_CERO;
    }
    
    return str_nuevo;
    
}

char** split(const char* str, char separador){
    char* item=NULL;
    char* vector=NULL;
    void* auxiliar1=NULL;
    int i=0;
    if(str==NULL){
        return NULL;
    }
    if( strlen(str)<=0){
        return NULL;
    }       
           
    while(str[i]!= separador){
        vector=dividir_str(str,i,separador,vector);
        printf("%s", vector);
        item=vector;
       // printf("%s", item);
            if(item!=NULL){
                auxiliar1=vtradd(auxiliar1,item);  
                vector=NULL;   
            }
    i++;
    }
    
    return auxiliar1;  
}

    
char* fgets_alloc(FILE* archivo){
    //fgets(str, 512, archivo);
    return NULL;
}

void fclosen(FILE* archivo){

}




char** split(const char* str, char separador){
   size_t tamanio_str= strlen(str);
   size_t i=0;
   size_t j=0;
   size_t k=0;
   size_t posicion_separador=0;
   size_t tamanio_substr=0;
   size_t posicion_inicial=0;
   char* auxiliar=NULL;
   char** ptr=NULL;
   bool es_null= false ;
    if(str==NULL){
        return NULL;
    }
    if(tamanio_str<=0){
        return NULL;
    }  
    while(str[i]<= tamanio_str){
        if((str[i]== separador) || str[tamanio_str] ){
            posicion_separador=i;
            tamanio_substr= posicion_separador -posicion_inicial +1;
            auxiliar = calloc( (sizeof(char)), tamanio_substr);
            if(!auxiliar){
                 es_null= true;
            } 
            j=0;
            k= posicion_inicial;
        while(i<tamanio_str && str[i]!=separador){
                auxiliar[j]=str[i];
                i++;
                j++;          
        } 
        
            ptr=vtradd(ptr, auxiliar);         
        
        posicion_inicial=posicion_separador+1;  
        }
                
        i++;
        }  
    return ptr;
}


+bytes_leidos+leido-1
+bytes_leidos+leido-1





salon_t* salon_leer_archivo(const char* nombre_archivo){
    
    FILE* archivo;
    archivo = fopen(nombre_archivo, "r");
    if(!archivo){
        return NULL;
    }    
    entrenador_t* entrenadores_nuevos=NULL;
    salon_t* salon_nuevo=NULL;
    void* ptr=NULL;
    char* linea_archivo=fgets_alloc(archivo);
    printf("%s\n", linea_archivo);
    int i=0;
    char separador= SEPARADOR;
    char** str_dividido =split(linea_archivo, separador);
    
    while(!feof(archivo)){
        
        while(linea_archivo[i]!=0){
            size_t tamanio_str= vtrlen(str_dividido);
            if(tamanio_str== 2){
                ptr=reservar_memoria_entrenador(str_dividido, tamanio_str);
                salon_nuevo->entrenadores= vtradd(salon_nuevo->entrenadores, ptr); 
            }else if(tamanio_str ==6){
                ptr=reservar_memoria_pokemones(str_dividido, tamanio_str);
                entrenadores_nuevos->equipo = vtradd(entrenadores_nuevos->equipo, ptr);
            } 
            i++;
            linea_archivo=fgets_alloc(archivo);
            printf("%s\n", linea_archivo);
            
        }
   }
    return salon_nuevo;
    
   return NULL;
}


























entrenador_t* reservar_memoria_entrenador(char** str_dividido, size_t tamanio_str){
    entrenador_t* entrenadores_aux;
    entrenadores_aux= calloc(tamanio_str, sizeof(entrenador_t));
    if(!entrenadores_aux){
        return NULL;
    }
    printf("%s\n", str_dividido[0]);
    strcpy(entrenadores_aux->nombre, str_dividido[0]);
    printf("%s\n", str_dividido[1]);
    entrenadores_aux->victorias= atoi(str_dividido[1]);

    return entrenadores_aux;
}
pokemon_t* reservar_memoria_pokemones(char** str_dividido, size_t tamanio_str){
    pokemon_t* pokemones_aux;
    pokemones_aux=calloc(tamanio_str, sizeof(entrenador_t));
    if(!pokemones_aux){
        return NULL;
    }
    printf("%s\n", str_dividido[0]);
    strcpy(pokemones_aux->nombre, str_dividido[0]);
    printf("%s\n", str_dividido[1]);
    pokemones_aux->nivel= atoi(str_dividido[1]);
    printf("%s\n", str_dividido[2]);
    pokemones_aux->defensa= atoi(str_dividido[2]);
    printf("%s\n", str_dividido[3]);
    pokemones_aux->fuerza= atoi(str_dividido[3]);
    printf("%s\n", str_dividido[4]);
    pokemones_aux->inteligencia= atoi(str_dividido[4]);
    printf("%s\n", str_dividido[5]);
    pokemones_aux->velocidad= atoi(str_dividido[5]);

    return pokemones_aux;
}
salon_t* salon_leer_archivo(const char* nombre_archivo){
    FILE* archivo;
    archivo = fopen(nombre_archivo, "r");
    if(!archivo){
        return NULL;
    }    
    salon_t* salon_nuevo;
    salon_nuevo= calloc(1,sizeof(entrenador_t));
        if(!salon_nuevo){
            return NULL;
        }
    entrenador_t* entrenadores_nuevos;
    entrenadores_nuevos = calloc(1,sizeof(entrenador_t));
        if(!entrenadores_nuevos){
            return NULL;
        }    
    
    entrenador_t* entrenador=NULL;
    pokemon_t* pokemon=NULL;
    char* linea_archivo= fgets_alloc(archivo);
    printf("%s\n", linea_archivo);
    char separador= SEPARADOR;
    //int i=0;
    //int j=0;
        while(linea_archivo!= NULL ){
            char** str_dividido =split(linea_archivo, separador);
            size_t tamanio_str= vtrlen(str_dividido);
            if(tamanio_str== 2){
                //i++;
                entrenador=reservar_memoria_entrenador(str_dividido, tamanio_str);
                salon_nuevo->entrenadores = vtradd(salon_nuevo->entrenadores,entrenador );
                
            }else if(tamanio_str ==6){
                pokemon=reservar_memoria_pokemones(str_dividido, tamanio_str);
                entrenadores_nuevos->equipo = vtradd(entrenadores_nuevos->equipo, pokemon);
                
            }
            
            //*salon_nuevo->entrenadores[j] =entrenadores_nuevos[i] ;
            linea_archivo=fgets_alloc(archivo);
        }    
    return salon_nuevo;
}






entrenador_t* reservar_memoria_entrenador(char** str_dividido, size_t tamanio_str){
    entrenador_t* entrenadores_aux;
    entrenadores_aux= malloc( sizeof(entrenador_t));
    if(!entrenadores_aux){
        return NULL;
    }
    printf("%s\n", str_dividido[0]);
    strcpy(entrenadores_aux->nombre, str_dividido[0]);
    printf("%s\n", str_dividido[1]);
    entrenadores_aux->victorias= atoi(str_dividido[1]);
    
    

    return entrenadores_aux;
}
pokemon_t* reservar_memoria_pokemones(char** str_dividido, size_t tamanio_str){
    pokemon_t* pokemones_aux;
    pokemones_aux=malloc( sizeof(entrenador_t));
    if(!pokemones_aux){
        return NULL;
    }
    printf("%s\n", str_dividido[0]);
    strcpy(pokemones_aux->nombre, str_dividido[0]);
    printf("%s\n", str_dividido[1]);
    pokemones_aux->nivel= atoi(str_dividido[1]);
    printf("%s\n", str_dividido[2]);
    pokemones_aux->defensa= atoi(str_dividido[2]);
    printf("%s\n", str_dividido[3]);
    pokemones_aux->fuerza= atoi(str_dividido[3]);
    printf("%s\n", str_dividido[4]);
    pokemones_aux->inteligencia= atoi(str_dividido[4]);
    printf("%s\n", str_dividido[5]);
    pokemones_aux->velocidad= atoi(str_dividido[5]);

    return pokemones_aux;
}
salon_t* salon_leer_archivo(const char* nombre_archivo){
    FILE* archivo;
    archivo = fopen(nombre_archivo, "r");
    if(!archivo){
        return NULL;
    }    
    salon_t* salon_nuevo;
    salon_nuevo= calloc(1,sizeof(entrenador_t));
        if(!salon_nuevo){
            return NULL;
        }
    entrenador_t* entrenadores_nuevos;
    entrenadores_nuevos = calloc(1,sizeof(entrenador_t));
        if(!entrenadores_nuevos){
            return NULL;
        }    
    
    entrenador_t* entrenador=NULL;
    pokemon_t* pokemon=NULL;
    char* linea_archivo= fgets_alloc(archivo);
    printf("%s\n", linea_archivo);
    char separador= SEPARADOR;
    int i=0;
    int j=0;
    
        while(linea_archivo!= NULL ){
            char** str_dividido =split(linea_archivo, separador);
            size_t tamanio_str= vtrlen(str_dividido);
            if(tamanio_str== CAMPOS_ENTRENADOR){            
                entrenador=reservar_memoria_entrenador(str_dividido, tamanio_str);
                salon_nuevo->entrenadores = vtradd(salon_nuevo->entrenadores,entrenador );
            }else if(tamanio_str ==CAMPOS_POKEMON){
                i++;
                pokemon=reservar_memoria_pokemones(str_dividido, tamanio_str);
                entrenadores_nuevos[i].equipo= vtradd(entrenadores_nuevos->equipo , pokemon);
                
            }
            *salon_nuevo->entrenadores[j] =entrenadores_nuevos[i] ;
            linea_archivo=fgets_alloc(archivo);
        }    
    return salon_nuevo;
}




entrenador_t* reservar_memoria_entrenador(char** str_dividido, size_t tamanio_str){
    entrenador_t* entrenadores_aux;
    entrenadores_aux= calloc(1, sizeof(entrenador_t));
    if(!entrenadores_aux){
        return NULL;
    }
    //printf("%s\n", str_dividido[0]);
    strcpy(entrenadores_aux->nombre, str_dividido[0]);
    //printf("%s\n", str_dividido[1]);
    entrenadores_aux->victorias= atoi(str_dividido[1]);
    
    return entrenadores_aux;
}
pokemon_t* reservar_memoria_pokemones(char** str_dividido, size_t tamanio_str){
    pokemon_t* pokemones_aux;
    pokemones_aux=calloc(1, sizeof(entrenador_t));
    if(!pokemones_aux){
        return NULL;
    }
    //printf("%s\n", str_dividido[0]);
    strcpy(pokemones_aux->nombre, str_dividido[0]);
    //printf("%s\n", str_dividido[1]);
    pokemones_aux->nivel= atoi(str_dividido[1]);
    //printf("%s\n", str_dividido[2]);
    pokemones_aux->defensa= atoi(str_dividido[2]);
    //printf("%s\n", str_dividido[3]);
    pokemones_aux->fuerza= atoi(str_dividido[3]);
    //printf("%s\n", str_dividido[4]);
    pokemones_aux->inteligencia= atoi(str_dividido[4]);
    //printf("%s\n", str_dividido[5]);
    pokemones_aux->velocidad= atoi(str_dividido[5]);

    return pokemones_aux;
}
salon_t* salon_leer_archivo(const char* nombre_archivo){
    if(nombre_archivo==NULL){
        return NULL;
    }
    FILE* archivo;
    archivo = fopen(nombre_archivo, "r");
    if(!archivo){
        return NULL;
    }    
    salon_t* salon_nuevo;
    salon_nuevo= calloc(1,sizeof(entrenador_t));
        if(!salon_nuevo){
            return NULL;
        }
    entrenador_t* entrenadores_nuevos;
    entrenadores_nuevos = calloc(1,sizeof(entrenador_t));
        if(!entrenadores_nuevos){
            return NULL;
        }    
    
    entrenador_t* entrenador=NULL;
    pokemon_t* pokemon= calloc(1, sizeof(pokemon_t));
    char* linea_archivo= fgets_alloc(archivo);
    //printf("%s\n", linea_archivo);
    char separador= SEPARADOR;
    int i=0;
    int j=0;
    char** str_dividido= calloc(1, sizeof(char**));
        while(linea_archivo!= NULL ){
             str_dividido =split(linea_archivo, separador);
            size_t tamanio_str= vtrlen(str_dividido);
            if(tamanio_str== CAMPOS_ENTRENADOR){            
                entrenador=reservar_memoria_entrenador(str_dividido, tamanio_str);
                salon_nuevo->entrenadores = vtradd(salon_nuevo->entrenadores,entrenador );
            }else if(tamanio_str ==CAMPOS_POKEMON){
                i++;
                pokemon=reservar_memoria_pokemones(str_dividido, tamanio_str);
                entrenadores_nuevos[i].equipo= vtradd(entrenadores_nuevos[i].equipo , pokemon);
            }else{
                return NULL;
            }
            *salon_nuevo->entrenadores[j]= entrenadores_nuevos[i] ;
            linea_archivo=fgets_alloc(archivo);
        }    
    return salon_nuevo;
}

for(int i=1; i<tamanio;i++){
        j=i;
        entrenador_aux= salon_aux->entrenadores[i]->victorias;
        while(j>0 && entrenador_aux<salon_aux->entrenadores[j-1]->victorias){
            salon_aux->entrenadores[j]->victorias= salon_aux->entrenadores[j+1]->victorias;
            j++;
        }
        salon_aux->entrenadores[j]->victorias=entrenador_aux;
    }


     
    int tamanio= (int)vtrlen(salon_aux->entrenadores);
    for(int i=0; i<tamanio;i++){
        for(int j=0; j<(tamanio-i-1);j++){
            if(salon_aux->entrenadores[j]->victorias>salon_aux->entrenadores[j+1]->victorias){
                entrenador_aux = salon_aux->entrenadores[j];
                salon_aux->entrenadores[j]= salon_aux->entrenadores[j+1];
                salon_aux->entrenadores[j+1]= entrenador_aux;
            }
        }
    }



//si hago esto me anda todo perfecto, sin errores de valgrind y todo
entrenador_t* entrenador_1 = calloc(1, sizeof(entrenador_t));
entrenador_t* entrenador_2 = calloc(1, sizeof(entrenador_t));
strcpy(entrenador_1->nombre, "entrenador_1");
strcpy(entrenador_2->nombre, "entrenador_2");
entrenador_1->victorias = 5;
entrenador_1->equipo = NULL;
entrenador_2->equipo = NULL;
salon = salon_agregar_entrenador(salon, entrenador_1);
salon = salon_agregar_entrenador(salon, entrenador_2);
​
// pero si hago esto se me rompe el programa  me tira segmentation fault, invalid read of size 4 y
// muchos errores de valgrin que asumo que son por el segmentation fault
​
entrenador_t* entrenador_1 = calloc(1, sizeof(entrenador_t));
entrenador_t* entrenador_2 = calloc(1, sizeof(entrenador_t));
strcpy(entrenador_1->nombre, "entrenador_1");
strcpy(entrenador_2->nombre, "entrenador_2");
entrenador_1->victorias = 5;
entrenador_2->victorias = 7;//el problema esta ACA
entrenador_1->equipo = NULL;
entrenador_2->equipo = NULL;
salon = salon_agregar_entrenador(salon, entrenador_1);
salon = salon_agregar_entrenador(salon, entrenador_2);
​
  return 0;
}